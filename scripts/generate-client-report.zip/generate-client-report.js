const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const resultsPath = path.join(projectRoot, 'test-results', 'results.json');
const outputDir = path.join(projectRoot, 'client-report');
const outputPath = path.join(outputDir, 'index.html');

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function collectTests(suites, parentTitle = []) {
  const tests = [];

  for (const suite of suites ?? []) {
    const suiteTitle = suite.title ? [...parentTitle, suite.title] : parentTitle;

    for (const spec of suite.specs ?? []) {
      for (const test of spec.tests ?? []) {
        for (const result of test.results ?? []) {
          tests.push({
            title: [...suiteTitle, spec.title].filter(Boolean).join(' > '),
            status: result.status,
            duration: result.duration ?? 0,
            project: test.projectName ?? '',
            error: result.error?.message ?? '',
          });
        }
      }
    }

    tests.push(...collectTests(suite.suites, suiteTitle));
  }

  return tests;
}

function formatDuration(ms) {
  const seconds = Math.round(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  if (minutes > 0) {
    return `${minutes}m ${remainingSeconds}s`;
  }

  return `${remainingSeconds}s`;
}

if (!fs.existsSync(resultsPath)) {
  console.error(`Missing Playwright JSON results: ${resultsPath}`);
  console.error('Run: npx playwright test --headed');
  process.exit(1);
}

const results = JSON.parse(fs.readFileSync(resultsPath, 'utf8'));
const tests = collectTests(results.suites);
const total = tests.length;
const passed = tests.filter(test => test.status === 'passed').length;
const failed = tests.filter(test => test.status === 'failed' || test.status === 'timedOut').length;
const skipped = tests.filter(test => test.status === 'skipped').length;
const interrupted = tests.filter(test => test.status === 'interrupted').length;
const totalDuration = tests.reduce((sum, test) => sum + test.duration, 0);
const generatedAt = new Date().toLocaleString();

const validations = [
  {
    area: 'New subscriber onboarding',
    checks: [
      'Account registration with generated email and US mobile number',
      'SMS OTP verification during sign-up',
      'Email verification handoff before login',
      'Risk profile completion',
      'Compliance profile completion and disclosure acceptance',
      'Income Builder plan selection',
      'Stripe checkout payment completion',
      'Dashboard access after successful onboarding',
    ],
  },
  {
    area: 'Profile',
    checks: [
      'Subscriber login',
      'Profile page access',
      'Profile data loads successfully',
      'Email field remains disabled/read-only',
    ],
  },
  {
    area: 'Password validation',
    checks: [
      'New password and confirm password mismatch validation',
      'Wrong current password validation',
      'Expected validation messages are displayed',
    ],
  },
  {
    area: 'Subscriber billing',
    checks: [
      'Dashboard access and refresh persistence',
      'Billing page navigation from profile menu',
      'Plans tab opens and Income Builder plan is visible',
      'Transaction history opens and paid status is verified',
      'Invoice page opens successfully',
      'Invoice PDF link is available and opens',
      'Subscriber logout completes successfully',
    ],
  },
];

const rows = tests
  .map(test => {
    const statusClass =
      test.status === 'passed'
        ? 'passed'
        : test.status === 'skipped'
          ? 'skipped'
          : 'failed';

    return `
      <tr>
        <td>${escapeHtml(test.title)}</td>
        <td>${escapeHtml(test.project)}</td>
        <td><span class="badge ${statusClass}">${escapeHtml(test.status)}</span></td>
        <td>${formatDuration(test.duration)}</td>
        <td>${escapeHtml(test.error)}</td>
      </tr>`;
  })
  .join('');

const validationCards = validations
  .map(group => `
    <article class="validation-card">
      <h3>${escapeHtml(group.area)}</h3>
      <ul>
        ${group.checks.map(check => `<li>${escapeHtml(check)}</li>`).join('')}
      </ul>
    </article>`)
  .join('');

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OOLTool PUAT Automation Client Report</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f6f8fb;
      --panel: #ffffff;
      --text: #172033;
      --muted: #5d6b82;
      --line: #dfe5ef;
      --green: #11845b;
      --red: #b42318;
      --amber: #946200;
      --blue: #2457c5;
    }

    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.45;
    }

    main {
      max-width: 1120px;
      margin: 0 auto;
      padding: 40px 28px;
    }

    header {
      margin-bottom: 28px;
    }

    h1 {
      margin: 0 0 8px;
      font-size: 30px;
    }

    .subtitle {
      color: var(--muted);
      margin: 0;
    }

    .summary {
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
      gap: 14px;
      margin: 28px 0;
    }

    .card {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 18px;
    }

    .label {
      color: var(--muted);
      font-size: 13px;
      margin-bottom: 8px;
    }

    .value {
      font-size: 28px;
      font-weight: 700;
    }

    section {
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 22px;
      margin-top: 18px;
    }

    h2 {
      margin: 0 0 14px;
      font-size: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }

    th, td {
      border-top: 1px solid var(--line);
      padding: 12px 10px;
      text-align: left;
      vertical-align: top;
    }

    th {
      color: var(--muted);
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: .04em;
    }

    .badge {
      border-radius: 999px;
      color: #fff;
      display: inline-block;
      font-size: 12px;
      font-weight: 700;
      padding: 4px 9px;
      text-transform: uppercase;
    }

    .passed { background: var(--green); }
    .failed { background: var(--red); }
    .skipped { background: var(--amber); }

    .notes {
      color: var(--muted);
      margin: 0;
    }

    .validation-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
    }

    .validation-card {
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 16px;
    }

    h3 {
      margin: 0 0 10px;
      font-size: 16px;
    }

    ul {
      margin: 0;
      padding-left: 20px;
      color: var(--muted);
    }

    li + li {
      margin-top: 6px;
    }

    @media (max-width: 800px) {
      .summary {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .validation-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <main>
    <header>
      <h1>OOLTool PUAT Automation Client Report</h1>
      <p class="subtitle">Generated ${escapeHtml(generatedAt)} from Playwright automated test results.</p>
    </header>

    <div class="summary">
      <div class="card"><div class="label">Total Tests</div><div class="value">${total}</div></div>
      <div class="card"><div class="label">Passed</div><div class="value">${passed}</div></div>
      <div class="card"><div class="label">Failed</div><div class="value">${failed}</div></div>
      <div class="card"><div class="label">Skipped</div><div class="value">${skipped}</div></div>
      <div class="card"><div class="label">Duration</div><div class="value">${formatDuration(totalDuration)}</div></div>
    </div>

    <section>
      <h2>Execution Summary</h2>
      <p class="notes">Environment: PUAT. Browser: Chromium. Some authentication flows require manual email-link confirmation in the Playwright browser. Skipped tests are expected when they require an external reset URL or a purposely locked account.</p>
      ${interrupted ? `<p class="notes">Interrupted tests: ${interrupted}</p>` : ''}
    </section>

    <section>
      <h2>What We Validated</h2>
      <div class="validation-grid">${validationCards}</div>
    </section>

    <section>
      <h2>Test Results</h2>
      <table>
        <thead>
          <tr>
            <th>Test</th>
            <th>Project</th>
            <th>Status</th>
            <th>Duration</th>
            <th>Error</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </section>
  </main>
</body>
</html>
`;

fs.mkdirSync(outputDir, {
  recursive: true
});

fs.writeFileSync(outputPath, html);
console.log(`Client report created: ${outputPath}`);
